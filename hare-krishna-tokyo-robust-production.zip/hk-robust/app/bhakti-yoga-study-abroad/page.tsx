export const metadata = { title: "バクティ・ヨガ留学" };
export default function Study() {
  return <main>
    <section className="hero" style={{minHeight:"55vh"}}><div className="wrap">
      <p className="eyebrow" style={{color:"#f3b32d"}}>EXPERIENCE INDIA</p>
      <h1>バクティ・ヨガ留学</h1>
      <p>観光ではなく、暮らしながら学ぶ。VrindavanとBangaloreで、自分の価値観を見つめ直す没入型プログラム。</p>
    </div></section>
    <section className="section"><div className="wrap">
      <div className="grid cards">
        <article className="card cardbody"><h2>Vrindavan</h2><p className="muted">聖地での生活、寺院訪問、キールタン、哲学クラス、地域コミュニティとの交流。</p></article>
        <article className="card cardbody"><h2>Bangalore</h2><p className="muted">都市型コミュニティでの奉仕、学び、ウェルネス習慣、英語を使った国際交流。</p></article>
        <article className="card cardbody"><h2>費用・期間</h2><p className="muted">期間、宿泊、食事、現地ガイド、航空券の扱いはプログラムごとに案内します。</p></article>
      </div>
      <form className="card cardbody" style={{marginTop:30,maxWidth:700}}>
        <h2>興味登録</h2><p><input style={{width:"100%",padding:14}} placeholder="お名前" required/></p>
        <p><input style={{width:"100%",padding:14}} type="email" placeholder="メール" required/></p>
        <p><textarea style={{width:"100%",padding:14,minHeight:120}} placeholder="参加可能な時期・動機" required/></p>
        <button className="btn">送信する</button>
      </form>
    </div></section>
  </main>;
}
