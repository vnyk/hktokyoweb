# Hare Krishna Tokyo Robust Production Release

## Deploy in about 15 minutes
1. Create client-owned Supabase and Vercel accounts.
2. Run `supabase/schema.sql` in Supabase SQL Editor.
3. In Supabase Auth, enable Email OTP and add `https://YOUR-DOMAIN/auth/callback` as a redirect URL.
4. Import the repository into Vercel and add all variables from `.env.example`.
5. Deploy, open `/api/health`, and confirm `{ "ok": true }`.
6. Open `/admin/login` with the exact `ADMIN_EMAIL` and test a magic-link login.
7. Place a test order from another phone, verify it in `/admin`, then remove the test record.

## Robustness included
- Central Supabase order storage, server-calculated trusted prices, in-stock validation, quantity limits, field-length limits, email/phone/address validation, honeypot spam trap, per-IP submission throttling, secure magic-link admin authentication, exact-email authorization, logout, order statuses, health endpoint, optional Resend new-order alert, RLS, database indexes, sitemap, robots and production build validation.

## Manual payment model
No payment data is collected. Orders remain requests until staff contacts the customer and marks payment status in admin.

## Required before launch
Fill legal and shipping details in `/admin`, publish privacy/manual-payment terms, verify the sending domain if using Resend, replace any old WordPress-hosted images before cancelling old hosting, retain the old host for 30 days, and test on iPhone Safari and Android Chrome.
