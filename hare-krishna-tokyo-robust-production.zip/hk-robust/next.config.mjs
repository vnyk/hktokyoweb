const nextConfig = {
  images: { remotePatterns: [{ protocol: 'https', hostname: 'harekrishna.jp', pathname: '/wp-content/uploads/**' }] },
  async redirects() {
    return [
      { source: '/cart.html', destination: '/shop', permanent: true },
      { source: '/checkout.html', destination: '/shop', permanent: true },
      { source: '/my-account.html', destination: '/shop', permanent: true }
    ];
  }
};
export default nextConfig;
